﻿<?php
echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";//页面宽度适配
echo "<title>{$_WebsiteName}</title>";
error_reporting(E_ALL ^ E_DEPRECATED);
?>