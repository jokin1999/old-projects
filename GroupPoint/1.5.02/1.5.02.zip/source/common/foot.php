﻿<?php
echo "<div class='foot' align='center'>";
echo "<a style='color: grey;font-size: 10px'>极科网络科技版权所有 <br />";
echo "Copyright JikeNetwork 2015<br />";
echo "{$_WebsiteName} {$_WebsiteVer}</a>";
echo "</div>";
?>