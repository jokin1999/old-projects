﻿<?php 
include '../../../../../root/SN.php';
include '../../../../../root/config.php';
include '../../../../common/head.php';
echo "<head><link rel='stylesheet' type='text/css' href='../../../../../style/user.css'></head>";
echo "<table border='0' width='device-width' align='center'>
	<tr><td colspan='2' align='center'><a class='WebsiteName'>{$_WebsiteName}</a><a class='WebsiteVer'>{$_WebsiteVer}</a></td></tr>";
$ID=$_GET['ID'];
$BuyUsername=$_GET['Buyer'];
	if (isset($_COOKIE['student'])){
		$Username=$_COOKIE['student'];
		$ConnectMysql = mysqli_connect($_DBHost,$_DBUsername,$_DBPassword,$_DBName);//连接sql服务器
		if (!$ConnectMysql){
			die('Could not connect: ' . mysqli_connect_error());
		}
		mysqli_select_db($ConnectMysql,$_DBName);
			$sql="SELECT * FROM `ssc` WHERE `ID` = '{$ID}'";//代入命令
			$result=mysqli_query($ConnectMysql,$sql);//查询数据
			$Info=mysqli_fetch_array($result);//排列数据
			mysqli_close($ConnectMysql);
			if ($Info['ID']==$ID){
				if ($Info['Open']=='1'){
					$Type=$Info['Type'];
					echo "<tr><td colspan='2'><hr /></td></tr>";//分割线
					echo"<form action='./buy_2.php?Username={$_COOKIE['student']}&ID={$ID}&Price={$Info['Price']}&Type={$Type}' method='Post'>";
					echo "<tr><td colspan='2' align='center'>本次交易金额：{$Info['Price']} {$_Point}</td></tr>";
					echo "<tr><td colspan='2' align='center'>本次交易将与 担保商城 进行。</td></tr>";
					echo "<tr><td colspan='2' align='center'><input type='submit' value='下一步'></td></tr>";
					echo "<tr><td colspan='2' align='center'><a href='../../shop_index.php'>返回商城</a></td></tr>";
					echo "<tr><td colspan='2'><hr /></td></tr></table>";//分割线
				}else{
					echo "<tr><td colspan='2' align='center'>您欲购买的商品已经下架。</td></tr>";
					echo "<tr><td colspan='2' align='center'><a href='../../shop_index.php'>返回商城</a></td></tr>";
					echo "<tr><td colspan='2'><hr /></td></tr></table>";//分割线
				}
			}else{
				echo "<tr><td colspan='2' style='color:red;' align='center'>商品不存在。</td></tr>";
				echo "<tr><td colspan='2' align='center'><a href='../../shop_index.php'>返回商城</a></td></tr>";
				echo "<tr><td colspan='2'><hr /></td></tr></table>";//分割线
			}
			
	}else{
		echo "<tr><td colspan='2' align='center'>您还没有登录，将返回首页。</td></tr>";
		echo "<tr><td colspan='2' align='center'><a href='../../../../../index.php'>没有反应请点击这里</td></tr>";
		echo "<tr><td colspan='2'><hr /></td></tr></table>";//分割线
		echo "<meta http-equiv='refresh' content='2;url=../../../../../index.php'> ";
	}
//foot
include "../../../../common/foot.php";
?>
