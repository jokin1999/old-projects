﻿<?php
include '../../../../../root/SN.php';
include '../../../../../root/config.php';
include '../../../../common/head.php';
echo "<head><link rel='stylesheet' type='text/css' href='../../../../../style/user.css'></head>";
echo "<table border='0' width='device-width' align='center'>
	<tr><td colspan='2' align='center'><a class='WebsiteName'>{$_WebsiteName}</a><a class='WebsiteVer'>{$_WebsiteVer}</a></td></tr>";
$Username=$_GET['Username'];
$ID=$_GET['ID'];
$Pay=$_GET['Price'];
	if (isset($_COOKIE['student'])){
			$ConnectMysql = mysqli_connect($_DBHost,$_DBUsername,$_DBPassword,$_DBName);//连接sql服务器
			if (!$ConnectMysql){
				die('Could not connect: ' . mysqli_connect_error());
			}
			mysqli_select_db($ConnectMysql,$_DBName);
			$sql="SELECT * FROM `account` WHERE `Username` = '{$Username}'";//代入命令
			$result=mysqli_query($ConnectMysql,$sql);//查询数据
			$Info=mysqli_fetch_array($result);//排列数据
			if($Info['Point']<$Pay){
				echo "<tr><td colspan='2' style='color:red;' align='center'>您的{$_Point}不足，无法购买！</td></tr>";
				echo "<tr class='button'><td colspan='2' align='center'><a href='../../shop_index.php'>返回商城</a></td></tr>";
			}else{
				//付款
				$temppoint=$Info['Point']-$Pay;
				$sql="UPDATE account SET Point = '{$temppoint}' WHERE `Username` = '{$_COOKIE['student']}' ";//代入命令
				$result=mysqli_query($ConnectMysql,$sql);//提交数据
				
				//写入购买订单记录
				$Username=$_GET['Username'];
				mysqli_select_db($ConnectMysql,$_DBName );
				$sql="SELECT * FROM `buy_record`";//代入命令
				$result=mysqli_query($ConnectMysql,$sql);//查询数据
				$count=0;
				while($row = mysqli_fetch_array($result)){
						$count++;
				}
				date_default_timezone_set('Asia/Shanghai');
				$Date=date('Y-m-d H:i:s');
				$BuyerUsername=$Username;


				//收款
				mysqli_select_db($ConnectMysql,$_DBName );
				$sql="SELECT * FROM `ssc` WHERE `ID` = '{$ID}'";//代入命令
				$result=mysqli_query($ConnectMysql,$sql);//查询数据
				$Info=mysqli_fetch_array($result);//排列数据	
				$Username=$Info['Username'];//卖家用户名
				
				mysqli_select_db($ConnectMysql,$_DBName );
				$sql="SELECT * FROM `account` WHERE `Username` = '{$Username}'";//代入命令
				$result=mysqli_query($ConnectMysql,$sql);//查询数据
				$Info=mysqli_fetch_array($result);//排列数据
				$temppoint=$Info['Point']+$Pay;
				$sql="UPDATE account SET Point = '{$temppoint}'WHERE `Username` = '{$Info['Username']}' ";//代入命令
				$result=mysqli_query($ConnectMysql,$sql);//提交数据
				
				$SellerUsername=$Username;
				
				//写入购买记录
				mysqli_select_db($ConnectMysql,$_DBName );
				mysqli_query($ConnectMysql,"INSERT INTO buy_record (ID, ShopID, SellerUsername, BuyerUsername, Type, Price, Date, Finish) 
				VALUES ('{$count}', '{$ID}', '{$SellerUsername}','{$BuyerUsername}','online','{$Pay}','{$Date}','1')");
				
				echo "<tr><td colspan='2' align='center'>支付完成，<a class='button' href='../../../record/buy/buy_record.php'>查看订单</a></td></tr>";
				echo "<tr><td colspan='2' align='center'><a href='../../../user.php'>返回个人中心</td></tr>";
				echo "<tr><td colspan='2'><hr /></td></tr>";//分割线
				echo "</table>";
				mysqli_close($ConnectMysql);
			}

	}else{
		echo "<tr><td colspan='2' style='color:red;' align='center'>您还没有登录，将返回首页。</td></tr>";
		echo "<tr><td colspan='2' align='center'><a href='../../../../../index.php'>没有反应请点击这里</td></tr>";
		echo "<tr><td colspan='2'><hr /></td></tr></table>";//分割线
		echo "<meta http-equiv='refresh' content='2;url=../../../../../index.php'> ";
	}
//foot
include "../../../../common/foot.php";
?>