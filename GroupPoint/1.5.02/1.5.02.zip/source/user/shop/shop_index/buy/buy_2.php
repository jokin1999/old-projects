﻿<?php
$Type=$_GET['Type'];
	if ($Type=='online'){
		include './buy_online.php';
	} 
	
	if ($Type=='offline'){
		include './buy_offline.php';
	} 
?>