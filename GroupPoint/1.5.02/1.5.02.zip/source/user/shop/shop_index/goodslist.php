﻿<?php
	$ConnectMysql = mysqli_connect($_DBHost,$_DBUsername,$_DBPassword,$_DBName);//连接sql服务器
	if (!$ConnectMysql){
		die('Could not connect: ' . mysqli_connect_error());
	}
	mysqli_select_db($ConnectMysql,$_DBName);
	$sql = "SELECT * FROM `ssc`\n"
    . "ORDER BY `ssc`.`Date` DESC LIMIT 0, 30 ";//代入命令
	$result=mysqli_query($ConnectMysql,$sql);//查询数据
	$count=0;
	echo "<tr class='menu'><td align='center'>名称</td><td align='center'>价格</td><td align='center'>发布日期</td><td align='center'>操作</td></tr>";
	while($row = mysqli_fetch_array($result))
	{
		if ($row['Open']=="1"){
			$count++;
			echo "<tr><td align='center'>{$row['Name']}</td><td align='center' style='color:red'>{$row['Price']}</td><td align='center' style='color:grey;'>{$row['Date']}</td>
			<td align='center'><a href='./shop_index/buy/buy_1.php?ID={$row['ID']}&Buyer={$_COOKIE['student']}'>购买</a></td></tr>";
		}
	}
	echo "<tr><td colspan='4' align='center'>有效商品数量为：{$count} 个。</td></tr>";
	echo "<tr><td colspan='4'><hr /></td></tr>";//分割线
?>