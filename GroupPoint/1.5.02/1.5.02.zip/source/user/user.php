﻿<?php 
include '../../root/SN.php';
include '../../root/config.php';
include '../common/head.php';
echo "<head><link rel='stylesheet' type='text/css' href='../../style/user.css'></head>";
	if (isset($_COOKIE['user'])){
			$ConnectMysql = mysqli_connect($_DBHost,$_DBUsername,$_DBPassword,$_DBName);//连接sql服务器
			if (!$ConnectMysql){
				die('Could not connect: ' . mysqli_connect_error());
			}
			mysqli_select_db($ConnectMysql,$_DBName);
			$sql="SELECT * FROM `account` WHERE `Username` = '{$_COOKIE['user']}'";//代入命令
			$result=mysqli_query($ConnectMysql,$sql);//查询数据
			$Info=mysqli_fetch_array($result);//排列数据
			mysqli_close($ConnectMysql);
		echo "<table border='0' width='device-width' align='center'><tr><td colspan='2' align='center'><a class='WebsiteName'>{$_WebsiteName}</a><a class='WebsiteVer'>{$_WebsiteVer}</a></td></tr>";
		echo "<tr><td colspan='2'>尊敬的{$_COOKIE['user']}（LV.{$Info['Righter']}）</td></tr>";
		echo "<tr><td colspan='2'>剩余的{$_Point}为：{$Info['Point']} 点</td></tr>";
		echo "<tr><td colspan='2' align='center'><a href='./logout.php'>退出登录</a></td></tr></table>";
		//PAY
		echo "<table border='0' width='device-width' align='center'>";
		echo "<tr><td colspan='2'><hr /></td></tr>";//分割线
		echo "<tr><td class='menu' colspan='2' align='center'>{$_Point}操作</td></tr>";
		echo "<tr><td><a href='./action/pay/action.php'>{$_Point}转账</a></td><td style='color:grey;'>{$_Point}转账服务</td></tr>";
		echo "<tr><td colspan='2'><hr /></td></tr>";//分割线
		
			if($Info['Student']>0){
			setcookie('student',$_COOKIE['user'], time()+3600, '/');
			social();//显示Social组件
			}
			
			if($Info['Righter']>7){
			setcookie('manager',$_COOKIE['user'], time()+3600, '/');
			admin();//显示管理组件
			}
		echo "</table>";
	}else{
		echo "<table border='0' width='device-width' align='center'><tr ><td colspan='2' align='center'><a class='WebsiteName'>{$_WebsiteName}</a><a class='WebsiteVer'>{$_WebsiteVer}</a></td></tr>";
		echo "<tr><td align='center'>您还没有登录，页面将在3秒内跳转。</td></tr>";
		echo "<tr><td align='center'><a href='../../index.php'>没有反应请点击这里</a></td></tr></table>";
		echo "<meta http-equiv='refresh' content='2;url=../../index.php'>";
	}
	
	//foot
	include "../common/foot.php";
	
//functionPart-------
	//Social组件
function social(){
	include '../../root/SN.php';
	echo "<tr><td class='menu' colspan='2' align='center'>SocialCenter</td></tr>";
	echo "<tr><td><a href='./shop/shop_index.php'>商城</a></td><td style='color:grey;'>{$_Point}购物中心</td></tr>";
	echo "<tr><td><a href='./earnpoint/index.php'>赚{$_Point}</a></td><td style='color:grey;'>常规收入{$_Point}</td></tr>";
	echo "<tr><td colspan='2'><hr /></td></tr>";//分割线
	echo "<tr><td class='menu' colspan='2' align='center'>个人中心</td></tr>";
	echo "<tr><td><a href='./record/buy/buy_record.php'>我的订单</a></td><td style='color:grey;'>查看购买项目</td></tr>";
	echo "<tr><td><a href='./record/sell/sell_record.php'>我的出售</a></td><td style='color:grey;'>查看售出项目</td></tr>";
	echo "<tr><td colspan='2'><hr /></td></tr>";//分割线
}
	//管理组件
function admin(){
	echo "<tr><td class='menu' colspan='2' align='center'>管理中心</td></tr>";
	echo "<tr><td><a href='../admin/manager.php'>管理</a></td><td style='color:grey;'>进入管理中心</td></tr>";
	echo "<tr><td colspan='2'><hr /></td></tr>";//分割线
	//include "../admin/aaig/getwaituser_count.php";
}
?>