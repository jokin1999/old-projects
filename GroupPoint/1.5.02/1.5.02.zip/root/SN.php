<?php
$_WebsiteName='团逗GroupDou';
$_WebsiteVer='1.5.02';
$_Point='逗币';
$_Point_Unit='个';
?>
