<?php
$_DBHost='localhost';
$_DBUsername='root';
$_DBPassword='';
$_DBName='gp';
?>